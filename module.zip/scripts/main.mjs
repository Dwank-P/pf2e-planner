import { getWorldMetadata, previewItemPack } from './snapshot.mjs';
import { openPairingDialog, pairWebsite, testWebsite, syncNow, status } from './sync.mjs';
import { PlannerConnectionMenu, PlannerSyncMenu, PlannerPlayerConnectMenu } from './menu.mjs';
import {registerLevelerButtons} from './actor-menu.mjs';
import {refreshLevelerPacks,notify} from './sync.mjs';

const MODULE_ID = 'pf2e-planner-bridge';

Hooks.once('init', () => {
  game.settings.register(MODULE_ID, 'websiteUrl', {
    name: 'Planner Website URL',
    hint: 'Non-secret connection address, managed through the pairing dialog.',
    scope: 'world', config: false, type: String, default: ''
  });
  game.settings.register(MODULE_ID, 'integrationId', {
    name: 'Planner Integration ID',
    hint: 'Non-secret campaign binding.',
    scope: 'world', config: false, type: String, default: ''
  });
  game.settings.register(MODULE_ID, 'syncedPacks', {
    name: 'Selected additional compendium packs',
    hint: 'Selected Item pack collections; managed under Select Compendium Collections.',
    scope:'world',config:false,type:String,default:'[]'
  });
  game.settings.registerMenu(MODULE_ID, 'connection', {
    name: 'Pair World',
    label: 'Pair World',
    hint: 'Enter a website URL and one-time pairing code; tests stay open.',
    icon: 'fa-solid fa-link',
    type: PlannerConnectionMenu,
    restricted: true
  });
  game.settings.registerMenu(MODULE_ID, 'sync', {
    name:'Sync Now', label:'Sync Now',
    hint:'Manually import saved selected compendium collections without pairing again.',
    icon:'fa-solid fa-arrows-rotate',
    type:PlannerSyncMenu, restricted:true
  });
  game.settings.registerMenu(MODULE_ID, 'connectPlayer', {
    name:'Connect my account', label:'Connect my account',
    hint:'Players: connect your own website account (a code from the campaign page) to send and pull your characters.',
    icon:'fa-solid fa-user-plus',
    type:PlannerPlayerConnectMenu, restricted:false
  });
  // Packs are chosen in PF2e Leveler's Compendium Manager; the Bridge syncs exactly those.
});

Hooks.once('ready', () => {
  if (!['pf2e','sf2e'].includes(game.system?.id)) return;
  // Everyone gets the Export / Pull buttons on Leveler's windows (players use their own connection).
  registerLevelerButtons();
  if (!game.user?.isGM) return;
  globalThis.PF2ePlannerBridge = Object.freeze({
    getWorldMetadata, previewItemPack, openPairingDialog,
    pairWebsite, testWebsite, syncNow, status
  });
  refreshLevelerPacks().catch(error=>
    console.warn('[PF2e Planner Bridge] Leveler catalog selection:',error.message));
  console.info('[PF2e Planner Bridge] v' +
    game.modules.get(MODULE_ID)?.version +
    ' — packs follow PF2e Leveler\'s Compendium Manager. Settings → PF2e Planner Bridge → Pair World / Sync Now.');

  if (game.users.activeGM?.id === game.user.id) {
    setTimeout(() => syncNow({auto:true}).catch(error => {
      if (!/not authorized|Pair this Foundry world/.test(error.message)) {
        console.warn('[PF2e Planner Bridge] Automatic catalog sync not completed:', error.message);
        notify('error','Sync failed — ' + error.message);
      }
    }), 1200);
  }
});
